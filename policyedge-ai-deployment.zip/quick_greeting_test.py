#!/usr/bin/env python3
import os, json, logging
os.environ['OPENAI_API_KEY'] = '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'
logging.basicConfig(level=logging.ERROR)

print("🎯 PolicyEdge Email Greeting Variations")
print("=" * 50)

from email_sender import EmailSender
import openai

class TestEmailSender(EmailSender):
    def __init__(self):
        self.openai_client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

mock_entry = {
    'structured_data': {
        'facility_name': 'Health Center at Bloomingdale',
        'penalty_amount': '$88,000',
        'enforcement_action_type': 'Notice of Assessment of Penalties'
    },
    'pdf_data': {
        'administrator_first_name': 'Avraham',
        'administrator_name': 'Avraham Ochs'
    }
}

with open('custom_prompt.txt', 'r') as f:
    prompt = f.read().strip()

email_sender = TestEmailSender()

for i in range(5):
    print(f"\n📧 EMAIL #{i+1}:")
    try:
        email = email_sender.generate_email_content([mock_entry], prompt)
        start = email.find('{')
        end = email.rfind('}') + 1
        if start != -1:
            data = json.loads(email[start:end])
            body = data.get('email_body', '')
            
            # Extract greeting
            if body.startswith('Dear'):
                greeting_type = "Dear"
            elif body.startswith('Hello'):
                greeting_type = "Hello"  
            elif body.startswith('Hi'):
                greeting_type = "Hi"
            else:
                greeting_type = "Other"
            
            first_sentence = body.split('.')[0] + '.'
            print(f"✅ {greeting_type}: {first_sentence}")
        else:
            print("❌ Could not parse")
    except Exception as e:
        print(f"❌ Error: {str(e)}")

print("\n🎉 You should see different greetings (Dear/Hello/Hi) across the samples!")
