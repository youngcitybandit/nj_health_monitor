#!/usr/bin/env python3
"""
Demo script to test the NJ Health Monitor with OpenAI API integration.
"""

import os
import sys
import logging
from datetime import datetime

# Set the OpenAI API key
os.environ['OPENAI_API_KEY'] = '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'

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def demo_full_workflow():
    """Demonstrate the complete workflow with real data."""
    try:
        print("🚀 NJ Health Facility Monitor - Full Demo with AI")
        print("=" * 60)
        
        # Step 1: Web Scraping
        print("\n1. 🌐 Web Scraping - Getting latest enforcement actions...")
        from web_scraper import NJHealthScraper
        scraper = NJHealthScraper()
        
        # Get the 3 most recent entries
        all_entries = scraper.get_all_entries()
        recent_entries = all_entries[:3]
        
        print(f"   ✓ Found {len(all_entries)} total enforcement actions")
        print(f"   ✓ Processing {len(recent_entries)} most recent entries:")
        
        for i, entry in enumerate(recent_entries, 1):
            print(f"     {i}. {entry['facility_name']} - {entry['enforcement_action']}")
        
        # Step 2: PDF Processing
        print("\n2. 📄 PDF Processing - Downloading and parsing PDFs...")
        from pdf_parser import PDFParser
        pdf_parser = PDFParser()
        
        processed_entries = []
        for i, entry in enumerate(recent_entries[:2], 1):  # Process first 2 entries
            try:
                print(f"   Processing entry {i}: {entry['facility_name']}")
                
                # Download PDF
                pdf_content = scraper.download_pdf(entry['pdf_url'])
                print(f"     ✓ Downloaded PDF ({len(pdf_content):,} bytes)")
                
                # Parse PDF
                parsed_data = pdf_parser.parse_pdf(pdf_content)
                print(f"     ✓ Extracted {len(parsed_data)} data fields")
                
                # Store for processing
                processed_entries.append({
                    'web_data': entry,
                    'pdf_data': parsed_data
                })
                
            except Exception as e:
                print(f"     ⚠ Error processing {entry['facility_name']}: {str(e)}")
        
        # Step 3: Data Processing
        print("\n3. 🔄 Data Processing - Structuring extracted information...")
        from data_processor import DataProcessor
        processor = DataProcessor()
        
        final_entries = []
        for entry_data in processed_entries:
            try:
                processed = processor.process_entry(entry_data['web_data'], entry_data['pdf_data'])
                final_entries.append(processed)
                
                structured = processed['structured_data']
                print(f"   ✓ {structured.get('facility_name', 'Unknown')}")
                print(f"     - Action: {structured.get('enforcement_action_type', 'N/A')}")
                print(f"     - Severity: {structured.get('severity_level', 'N/A')}")
                print(f"     - Priority Score: {structured.get('priority_score', 0)}/100")
                
            except Exception as e:
                print(f"     ⚠ Error processing entry: {str(e)}")
        
        # Step 4: AI Email Generation
        print("\n4. 🤖 AI Email Generation - Creating professional notification...")
        
        # Mock email sender that doesn't require Gmail credentials
        class MockEmailSender:
            def __init__(self):
                import openai
                self.openai_client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            
            def generate_email_content(self, processed_entries):
                """Generate email content using ChatGPT."""
                try:
                    # Prepare summary
                    entries_summary = []
                    for entry in processed_entries:
                        structured = entry.get('structured_data', {})
                        entries_summary.append({
                            'facility_name': structured.get('facility_name', 'Unknown'),
                            'enforcement_action_type': structured.get('enforcement_action_type', 'Unknown'),
                            'enforcement_date': structured.get('enforcement_date', 'Unknown'),
                            'penalty_amount': structured.get('penalty_amount', ''),
                            'severity_level': structured.get('severity_level', 'LOW'),
                            'priority_score': structured.get('priority_score', 0),
                            'violation_summary': structured.get('violation_summary', '')[:200]
                        })
                    
                    # Create prompt
                    prompt = f"""
Generate a professional email notification about {len(entries_summary)} new healthcare facility enforcement action(s) in New Jersey.

Here are the details:

"""
                    
                    for i, entry in enumerate(entries_summary, 1):
                        prompt += f"""
{i}. Facility: {entry['facility_name']}
   Action Type: {entry['enforcement_action_type']}
   Date: {entry['enforcement_date']}
   Severity: {entry['severity_level']}
   Priority Score: {entry['priority_score']}/100
"""
                        if entry['penalty_amount']:
                            prompt += f"   Penalty: {entry['penalty_amount']}\n"
                        
                        if entry['violation_summary']:
                            prompt += f"   Summary: {entry['violation_summary']}...\n"
                    
                    prompt += """

Please generate a professional email that:
1. Has a clear, informative subject line
2. Provides a brief summary of the enforcement actions
3. Highlights the most critical issues
4. Maintains a professional tone suitable for healthcare compliance professionals

Format the email in HTML for better readability.
"""
                    
                    # Generate email
                    response = self.openai_client.chat.completions.create(
                        model="gpt-4",
                        messages=[
                            {
                                "role": "system",
                                "content": "You are a professional healthcare compliance analyst. Generate clear, concise email notifications about healthcare facility enforcement actions."
                            },
                            {
                                "role": "user", 
                                "content": prompt
                            }
                        ],
                        max_tokens=1500,
                        temperature=0.7
                    )
                    
                    return response.choices[0].message.content
                    
                except Exception as e:
                    logger.error(f"Error generating email: {str(e)}")
                    return f"Error generating email: {str(e)}"
        
        email_sender = MockEmailSender()
        email_content = email_sender.generate_email_content(final_entries)
        
        print("   ✓ AI-generated email content:")
        print("   " + "─" * 58)
        print(email_content)
        print("   " + "─" * 58)
        
        # Step 5: Summary
        print("\n5. 📊 Summary")
        print(f"   • Monitored website: ✓")
        print(f"   • Downloaded {len(processed_entries)} PDFs: ✓")
        print(f"   • Extracted data from {len(final_entries)} entries: ✓")
        print(f"   • Generated AI email notification: ✓")
        
        print("\n🎉 Demo completed successfully!")
        print("\nNext steps to go fully live:")
        print("1. Set up Supabase database for data storage")
        print("2. Configure Gmail API for email sending")
        print("3. Run: python3 main.py --once (for one-time test)")
        print("4. Run: python3 main.py (for daily monitoring)")
        
        return True
        
    except Exception as e:
        logger.error(f"Demo failed: {str(e)}")
        return False

if __name__ == "__main__":
    demo_full_workflow()
